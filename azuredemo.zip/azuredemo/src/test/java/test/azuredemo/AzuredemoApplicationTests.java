package test.azuredemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzuredemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
